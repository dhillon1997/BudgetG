package com.example.amanat.mad_project;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Signup extends AppCompatActivity {
    EditText enterEmail,enterPassword;
    Button submit, goBack;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);
            enterEmail = (EditText)findViewById(R.id.enterEmail);
            enterPassword = (EditText)findViewById(R.id.enterPassword);
            submit=(Button)findViewById(R.id.submit);
            goBack = (Button)findViewById(R.id.goBack);

            if((!TextUtils.isEmpty(enterEmail.toString())) && (!TextUtils.isEmpty(enterPassword.toString()))){

                submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatabaseReference childref = myRef.child(enterEmail.getText().toString().concat(enterPassword.getText().toString()));
                        childref.push().setValue(enterEmail.getText().toString());
                        childref.push().setValue(enterPassword.getText().toString());
                        childref.child("groceries").setValue("0");
                        childref.child("water").setValue("0");
                        childref.child("electricity").setValue("0");
                        childref.child("misc").setValue("0");
                        childref.child("income").setValue("0");
                        Intent in = new Intent(getApplicationContext(),Login.class);
                        startActivity(in);
                    }
                });
            }
            else{
                Toast.makeText(this,"Please enter the values",Toast.LENGTH_LONG);
                enterEmail.setText("");
                enterPassword.setText("");
            }
            goBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });

        }

    }
