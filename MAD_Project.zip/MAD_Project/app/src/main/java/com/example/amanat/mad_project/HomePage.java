package com.example.amanat.mad_project;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomePage extends AppCompatActivity {
    Button addGroceries, subGroceries, addElectricity, subElectricity, addWater, subWater, addMisc, subMisc, showExp;
    EditText groceries, electricity, water, misc,income;
    TextView display;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();
    Fragment fragment;

    SharedPreferences sharedpreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        addGroceries = (Button) findViewById(R.id.addGroceries);
        addElectricity = (Button) findViewById(R.id.addElectricity);
        addWater = (Button) findViewById(R.id.addWater);
        addMisc = (Button) findViewById(R.id.addMisc);
        subGroceries = (Button) findViewById(R.id.subGroceries);
        subElectricity = (Button) findViewById(R.id.subElectricity);
        subWater = (Button) findViewById(R.id.subWater);
        subMisc = (Button) findViewById(R.id.subMisc);
        showExp = (Button) findViewById(R.id.showExpenditure);

        groceries = (EditText) findViewById(R.id.groceries);
        electricity = (EditText) findViewById(R.id.electricity);
        water = (EditText) findViewById(R.id.water);
        misc = (EditText) findViewById(R.id.misc);
        display = (TextView)findViewById(R.id.display);
        income = (EditText)findViewById(R.id.income);
        addGroceries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                groceries.setText("" + add(Integer.parseInt(groceries.getText().toString())));
            }
        });
        subGroceries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sub(Integer.parseInt(groceries.getText().toString())) < 0) {
                    groceries.setText("0");
                } else {
                    groceries.setText("" + sub(Integer.parseInt(groceries.getText().toString())));
                }

            }
        });

        addElectricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                electricity.setText("" + add(Integer.parseInt(electricity.getText().toString())));
            }
        });
        subElectricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sub(Integer.parseInt(electricity.getText().toString())) < 0) {
                    electricity.setText("0");
                } else {
                    electricity.setText("" + sub(Integer.parseInt(electricity.getText().toString())));
                }

            }
        });


        addWater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                water.setText("" + add(Integer.parseInt(water.getText().toString())));
            }
        });
        subWater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sub(Integer.parseInt(water.getText().toString())) < 0) {
                    water.setText("0");
                } else {
                    water.setText("" + sub(Integer.parseInt(water.getText().toString())));
                }

            }
        });
        addMisc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                misc.setText("" + add(Integer.parseInt(misc.getText().toString())));
            }
        });
        subMisc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sub(Integer.parseInt(misc.getText().toString())) < 0) {
                    misc.setText("0");
                } else {
                    misc.setText("" + sub(Integer.parseInt(misc.getText().toString())));
                }

            }
        });

        showExp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myRef.child(getIntent().getExtras().getString("username")).child("groceries").setValue(groceries.getText().toString());
                myRef.child(getIntent().getExtras().getString("username")).child("water").setValue(water.getText().toString());
                myRef.child(getIntent().getExtras().getString("username")).child("electricity").setValue(electricity.getText().toString());
                myRef.child(getIntent().getExtras().getString("username")).child("misc").setValue(misc.getText().toString());
                myRef.child(getIntent().getExtras().getString("username")).child("income").setValue(income.getText().toString());

                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot)
                    {
                        String gr = "Groceries: "+dataSnapshot.child(getIntent().getExtras().getString("username")).child("groceries").getValue(String.class)+ "-----"+"Water: "+dataSnapshot.child(getIntent().getExtras().getString("username")).child("water").getValue(String.class)+"--------"+" Electricity: "+dataSnapshot.child(getIntent().getExtras().getString("username")).child("electricity").getValue(String.class)+ "------------"+"Misc"+dataSnapshot.child(getIntent().getExtras().getString("username")).child("misc").getValue(String.class)+"----------------->"+" INCOME: "+
                        dataSnapshot.child(getIntent().getExtras().getString("username")).child("income").getValue(String.class);
                        display.setText("Groceries: "+gr);


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }

        });

    }
        });
    }
    public int add(int num) {
        num = num + 100;
        return num;
    }

    public int sub(int num) {
        num = num - 100;
        return num;

    }
}








