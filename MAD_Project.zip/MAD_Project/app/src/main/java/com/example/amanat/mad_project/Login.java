package com.example.amanat.mad_project;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {
EditText enterEmail,enterPassword;
Button submit, goBack;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        enterEmail = (EditText) findViewById(R.id.enterEmail);
        enterPassword = (EditText) findViewById(R.id.enterPassword);
        submit = (Button) findViewById(R.id.submit);
        goBack = (Button) findViewById(R.id.goBack);
        if ((!TextUtils.isEmpty(enterEmail.toString())) && (!TextUtils.isEmpty(enterPassword.toString()))) {

            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            boolean flag = false;
                            for(DataSnapshot child: dataSnapshot.getChildren()){
                                if (child.getKey().matches(enterEmail.getText().toString().concat(enterPassword.getText().toString()))){
                                    Toast.makeText(getBaseContext(),"match" ,Toast.LENGTH_LONG).show();
                                    flag = true;
                                    break;
                                }
                            }
                            if(!flag){
                                Toast.makeText(getBaseContext(),"Please check value entered" ,Toast.LENGTH_LONG).show();

                            }
                            else{
                                Intent in = new Intent(getApplicationContext(),HomePage.class);
                                in.putExtra("username",enterEmail.getText().toString().concat(enterPassword.getText().toString()));
                                startActivity(in);

                            }

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
            });
            goBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });

        }
    }
    }

